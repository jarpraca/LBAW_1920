# lbaw2053

## 6. Online auctions

* Carlos Miguel Sousa Vieira, up201606868@fe.up.pt
* João Alberto Preto Rodrigues Praça, up201704748@fe.up.pt
* Lucas Tomás Martins Ribeiro, up201705227@fe.up.pt
* Silvia Jorge Moreira da Rocha, up201704684@fe.up.pt

