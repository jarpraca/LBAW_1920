<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AnimalPhoto extends Model
{
    public $timestamps  = false;

}
