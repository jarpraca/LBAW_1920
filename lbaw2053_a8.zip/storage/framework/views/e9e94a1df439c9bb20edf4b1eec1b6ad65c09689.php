<div class="d-flex flex-row ml-4 mb-0 bid_entry" data-id="<?php echo e($bid->id); ?>">
  <p class="w-50 ml-3 text-left mb-0 "><?php echo e($bid->name); ?></p>
  <p class="w-50 text-center mb-0"><?php echo e($bid->value); ?>€</p>
</div><?php /**PATH /home/silviavrocha/lbaw2053/resources/views/partials/bid_entry.blade.php ENDPATH**/ ?>