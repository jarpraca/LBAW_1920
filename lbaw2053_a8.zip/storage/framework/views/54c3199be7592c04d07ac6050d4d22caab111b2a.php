<?php echo e($slot); ?>

<?php /**PATH /home/silviavrocha/lbaw2053/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>