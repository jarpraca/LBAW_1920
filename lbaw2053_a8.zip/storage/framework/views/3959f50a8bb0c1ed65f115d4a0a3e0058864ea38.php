<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-white pt-4">
    <div class="pb-5 text-left mainBody">
        <h2 class="mt-3 text-dark">Trending</h2>
        <div class="d-flex flex-wrap text-left justify-content-around">
            <?php echo $__env->renderEach('partials.card', $auctions, 'auction'); ?>
        </div>

        <h2 class="mt-3 text-dark">Categories</h2>
        <div class="d-flex flex-row flex-wrap mt-4 rounded overflow-hidden">
            <a class="card text-white border-0 rounded-0 category-card" href="search.php">
                <img class="card-img rounded-0" src="<?php echo e(asset('assets/mammals.jpg')); ?>" alt="Card image">
                <div class="card-img-overlay d-flex justify-content-center align-items-center">
                    <h3 class="card-title text-center text-shadow">Mammals</h3>
                </div>
            </a>
            <a class="card text-white border-0 rounded-0 category-card" href="search.php">
                <img class="card-img rounded-0" src="<?php echo e(asset('assets/insects.jpg')); ?>" alt="Card image">
                <div class="card-img-overlay d-flex justify-content-center align-items-center">
                    <h3 class="card-title text-center text-shadow">Insects</h3>
                </div>
            </a>
            <a class="card text-white border-0 rounded-0 category-card" href="search.php">
                <img class="card-img rounded-0" src="<?php echo e(asset('assets/reptiles.jpg')); ?>" alt="Card image">
                <div class="card-img-overlay d-flex justify-content-center align-items-center">
                    <h3 class="card-title text-center text-shadow">Reptiles</h3>
                </div>
            </a>
            <a class="card text-white border-0 rounded-0 category-card" href="search.php">
                <img class="card-img rounded-0" src="<?php echo e(asset('assets/birds.png')); ?>" alt="Card image">
                <div class="card-img-overlay d-flex justify-content-center align-items-center">
                    <h3 class="card-title text-center text-shadow">Birds</h3>
                </div>
            </a>
            <a class="card text-white border-0 rounded-0 category-card" href="search.php">
                <img class="card-img rounded-0" src="<?php echo e(asset('assets/fishes.jpeg')); ?>" alt="Card image">
                <div class="card-img-overlay d-flex justify-content-center align-items-center">
                    <h3 class="card-title text-center text-shadow">Fishes</h3>
                </div>

            </a>
            <a class="card text-white border-0 rounded-0 category-card" href="search.php">
                <img class="card-img rounded-0" src="<?php echo e(asset('assets/amphibians.jpg')); ?>" alt="Card image">
                <div class="card-img-overlay d-flex justify-content-center align-items-center">
                    <h3 class="card-title text-center text-shadow">Amphibians</h3>
                </div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/silviavrocha/lbaw2053/resources/views/pages/homepage.blade.php ENDPATH**/ ?>